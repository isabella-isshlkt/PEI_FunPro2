// Lista de Compras
const listaDeCompras = [
  {nome: "Arroz", preco: 12},
  {nome: "Mouse", preco: 65},
  {nome: "Boneca", preco: 55},
  {nome: "Teclado", preco: 120}
]

console.log (listaDeCompras)

// Push: Adicionar item na lista

listaDeCompras.push ({
  nome: "Fone de Ouvido",
  preco: 75
})

console.log(listaDeCompras)

// Map: percorre o array e modifica cada um dos itens individualmente

const nomes = listaDeCompras.map(item => item.nome);

// Filter: Filtrar produtos acima de R$50

const caros = listaDeCompras.filter(item => item.preco > 50)

console.log("Itens acima de R$50:");

console.log(caros);