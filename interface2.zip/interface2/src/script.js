const form = document.querySelector("#formTarefa");
// pega o formulário

const input = document.querySelector("#inputTarefa");
// pega o campo de texto

const listaPendentes = document.querySelector("#listaPendentes");
// pega a lista de tarefas pendentes

const listaConcluidas = document.querySelector("#listaConcluidas");
// pega a lista de tarefas concluídas


// evento quando adiciona uma tarefa
form.addEventListener("submit", function (e) {
  e.preventDefault();
  // impede a página de recarregar

  const texto = input.value.trim();
  // pega o texto digitado

  if (texto === "") return;
  // se estiver vazio, não faz nada

  const li = document.createElement("li");
  // cria um item da lista


  const checkbox = document.createElement("input");
  // cria o checkbox
  checkbox.type = "checkbox";


  const span = document.createElement("span");
  // cria o texto da tarefa
  span.textContent = texto;


  const botaoRemover = document.createElement("button");
  // cria botão de remover
  botaoRemover.textContent = "Remover";


  // remove a tarefa quando clicar
  botaoRemover.addEventListener("click", function () {
    li.remove();
  });


  // quando marcar/desmarcar o checkbox
  checkbox.addEventListener("change", function () {
    if (checkbox.checked) {
      listaConcluidas.appendChild(li);
      // move para concluídas
    } else {
      listaPendentes.appendChild(li);
      // volta para pendentes
    }
  });


  // monta o item da lista
  li.appendChild(checkbox);
  li.appendChild(span);
  li.appendChild(botaoRemover);


  // adiciona na lista de pendentes por padrão
  listaPendentes.appendChild(li);

  // limpa o campo de texto
  input.value = "";
});