// Objeto Produto

const produto = {
    nome: "Notebook",
    preco: 3000,
    disponivel: true,

    atualizarPreco(novoPreco) {
        this.preco = novoPreco;
    },

    alterarStatus() {
        this.disponivel = !this.disponivel;
    }
};

produto.atualizarPreco(3500);
produto.alterarStatus();

console.log(produto);