console.clear()
//
//
//


// Funções matemáticas

const soma = (a, b) => a + b;

const subtracao = (a, b) => a - b;

const areaTriangulo = (base, altura) => (base * altura) / 2;

console.log("Soma:", soma(10, 5));
console.log("Subtração:", subtracao(10, 5));
console.log("Área do triângulo:", areaTriangulo(8, 4));
