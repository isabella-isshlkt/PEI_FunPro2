console.clear()
console.log("============If/else=============")
//
//
//

let nome = "Isabella";
console.log (nome)

let idade = 16;
  if (idade >= 18) {
    console.log ("É de maior")
  }

  else {
    console.log ("É de menor")
  }

console.log (idade) // No exemplo, a pessoa é de menor

nome2 = "César Olavo";
console.log (nome2)

idade2 = 35;
  if (idade2 >= 18) {
    console.log ("De maior")
  }

  else {
    console.log ("De menor")
  }

console.log (idade2)
// No exemplo, a pessoa é de maior

//
//
//
console.log("============ Switch =============")
//
//
//

let diaSemana = 3;

switch (diaSemana) {
    
  case 1:
    console.log("Domingo");
    break;
    
  case 2:
    console.log("Segunda-feira");
    break;
    
  case 3:
    console.log("Terça-feira");
    break;
    
  case 4:
    console.log("Quarta-feira");
    break;
    
  case 5:
    console.log("Quinra-feira");
    break;
    
  case 6:
    console.log("Sexta-feira");
    break;
    
  case 7:
    console.log("Sábado");
    break;
    
}
//
//
//
console.log("============ For =============")
//
//
//

for(i=4; i>0; i--) {
  console.log(i)
}

//
//
//
console.log("============ While =============")
//
//
//

let k = 7
while (k > 2) {
  console.log("ei")
  k = (k - 1)
}


//
//
//
console.log("============ Aprovado / Reprovado =============")
//
//
//

let nota = 9;

if (nota >= 6) {
  console.log("Aprovado!")
} else {
  console.log("Reprovado:c")
}