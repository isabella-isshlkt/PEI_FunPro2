console.log ("-----------")
const nome = "Isabella"; // const imutável
let idade; // "variável indefinida"

console.log(idade); // undefined

idade = 16;
let ehMaiorDeIdade = idade >= 18;
let formatura = null;



console.log("Olá, meu nome é " + nome + " e tenho " + idade +" anos"); // Mostra no console a junção das variáveis
console.log(ehMaiorDeIdade); // Resposta para pergunta: é maior de idade?
console.log(formatura); // Pergunta: Data de formatura
console.log(ehMaiorDeIdade); // Pergunta: É maior de idade?