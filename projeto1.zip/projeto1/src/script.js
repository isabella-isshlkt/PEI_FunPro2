// Promises: "Eu vou te entregar um resultado depois"

console.log ("O código funciona?")

const promessa = new Promise ((resolve,reject ) =>{
  let sucesso = true;
  
  if (sucesso) {
    resolve ("Funcionou :)");
  }
  else {
    reject ("Não funcionou :(");
  }
});

promessa
.then (resultado => {
  console.log(resultado);
})
.catch (erro => {
  console.log(erro);
});

// setTimeOut: executa ago frpois de determinado tempo

setTimeout(() => {
    console.log("setTimeOut: Passaram 3 segundos");
}, 3000); 

// Async: transforma uma função em uma função assíncrona

async function buscarGitHub () {
   
  const resposta =
        await fetch (
        "https://api.github.com/users/isabella-isshlkt"
        );
  const dados = 
        await resposta.json();
  console.log("Login: " + dados.login);
}

buscarGitHub();
 
