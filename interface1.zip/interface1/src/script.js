let cor = 0;

function alterarCor() {
  const title = document.querySelector("#title");
  const text = document.querySelector("#text");

  switch (cor) {

    case 0:
      document.body.style.backgroundColor = "lightblue";
      title.style.color = "darkblue";

      title.textContent = "Minha Página Azul";
      text.textContent = "Clique para mudar novamente";

      cor = 1;
      break;

    case 1:
      document.body.style.backgroundColor = "lightpink";
      title.style.color = "deeppink";

      title.textContent = "Minha Página Rosa";
      text.textContent = "Clique para voltar ao normal";

      cor = 2;
      break;

    case 2:
      document.body.style.backgroundColor = "";
      title.style.color = "";

      title.textContent = "Minha Página";
      text.textContent = "Clique no botão para mudar a cor da página";

      cor = 0;
      break;
  }
}